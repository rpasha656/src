import { Component, Inject } from '@angular/core';
import { Title, PubSubServiceContract } from 'microui-contracts';
import { FileMetadataService } from './filemetadata.service';
import { FileMetadataListing } from './filemetadatalisting.model';
import { SubCategories } from './filemetadatalisting.model';
import { FileMetadataModel } from './filemetadatalisting.model';
import { FileMetadata } from './filemetadata.model';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
@Component({
    moduleId: module.id,
    selector: 'as-docpub',
    template: require('./docpub.component.html')
})
export class DocpubComponent {
    public expDate: String;
    public date: Date;
    public showErrorMsg: boolean;
    public displayName: string;
    public fileMetadata: FileMetadata;
    public minExpDate: string;
    public filemetadatalisting: FileMetadataListing[];
    public subcategory: SubCategories[];
    public subJsonData: Object[];
    public category: FileMetadataListing[];
    public filemetadatamodel: FileMetadataModel[];
    public showfilelisting: Boolean;
    public fileUploadSuccess: number;
    public complexForm: FormGroup;
    isSubmitClicked: boolean;
    constructor(private pubsub: PubSubServiceContract, @Inject(Title) public title: string,
        private filemetadataService: FileMetadataService, fb: FormBuilder) {
        this.subcategory = [];
        this.filemetadatamodel = [];
        this.filemetadatalisting = [new FileMetadataListing(this.subcategory)];
        this.fileMetadata = new FileMetadata(new Date(), 0, 0, new Date(), 0, ' ', ' ', ' ', new Date(), 2, 1);
        this.minExpDate = new Date(new Date().setFullYear(new Date().getFullYear() + 1)).toISOString().split('T')[0];
        this.subcategory = [];
        this.category = [new FileMetadataListing(this.subcategory)];
        this.filemetadataService.getCategories().subscribe(res => this.category = res);
        this.fileUploadSuccess = 0;
        this.complexForm = fb.group({
            'file': [null, Validators.required],
            'fileName': [null, Validators.compose([Validators.required, Validators.maxLength(40)])],
            'expDate': [null, Validators.required]
        });
    }
    ngOnInit() {
        this.date = new Date();
        this.date.setFullYear(this.date.getFullYear() + 1);
        this.fileMetadata.expirationDate = this.date.toISOString().split('T')[0];
    }
    changeSubCate(selectedCategory) {
        for (let x = 0; x < this.category.length; x++) {
            console.log(selectedCategory.target.value);
            if (this.category[x].id === Number(selectedCategory.target.value)) {
                console.log(this.category[x].subCategories);
                this.subJsonData = this.category[x].subCategories;
            }
        }
        console.log(this.subJsonData);
    }
    fileChanged(event: any) {
        console.log(event.srcElement.files);
        this.fileMetadata.file = event.srcElement.files;
    }
    clear() {
        this.fileMetadata.clear();
        this.showErrorMsg = false;
        // document.getElementById('file').value = '';
        this.fileMetadata.expirationDate = this.date.toISOString().split('T')[0];
    }
    changeYear(event: any) {
        if (event.keyCode === 38 || event.keyCode === 40) {
            let from = event.target.value.split('-');
            // event.target.value =new Date(from[2], from[1] - 1, from[0]);
            console.log(new Date(from[0], from[1], from[2]));
        }
        return false;
    }
    /*stringToDate(_date, _format, _delimiter) {
        var formatLowerCase = _format.toLowerCase();
        var formatItems = formatLowerCase.split(_delimiter);
        var dateItems = _date.split(_delimiter);
        var monthIndex = formatItems.indexOf('mm');
        var dayIndex = formatItems.indexOf('dd');
        var yearIndex = formatItems.indexOf('yyyy');
        var month = parseInt(dateItems[monthIndex]);
        month -= 1;
        var formatedDate = new Date(dateItems[yearIndex], month, dateItems[dayIndex]);
        return formatedDate;
    }*/
    checkLength(name) {
        if (name.target.value && (name.target.value.toString().length >= 40)) {
            console.log(this);
            this.showErrorMsg = true;
            name.target.value = name.target.value.substring(0, 40);
        } else {
            this.showErrorMsg = false;
        }
    }
    addFileMetaData() {
        let fileMetadata = FileMetadata.clone(this.fileMetadata);
        this.filemetadataService.addFileMetaData(fileMetadata).subscribe(res => this.addSuccessfull(res));
    };
    addSuccessfull(createdFileMetadataId: number) {
        if (createdFileMetadataId > 0) { this.fileMetadata.clear(); this.fileUploadSuccess = createdFileMetadataId; }
        if (createdFileMetadataId < 0) { this.fileUploadSuccess = -1; }
    }
    getFileMetadatalisting(planname: string) {
        this.showfilelisting = true;
        this.filemetadataService.getFileMetadatalisting(planname).subscribe(res => this.filemetadatalisting = res.categories);
    };
    generateId(uniqueId: string) {
        return '#' + uniqueId;
    };
}
