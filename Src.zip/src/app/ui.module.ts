import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { DocpubRoutes, DocpubModule } from './docpub/index';
import { DatepickerModule } from 'angular2-material-datepicker';
@NgModule({
    declarations: [
    ],
    imports: [
        DocpubModule,
        DatepickerModule,
        RouterModule.forChild(DocpubRoutes)

    ],
    providers: []
})
export class UiModule {
}
